﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp32
{
    class Program
    {

        static int[] Soma(int[] vetor1, int[] vetor2)
        {
            int[] vetor3 = new int[5];
            for (int i = 0; i < vetor1.Length; i++)
            {
                vetor3[i] = vetor1[i] + vetor2[i];
            }
            return vetor3;
        }

        static int[] Multiplicação(int[] vetor1, int[] vetor2)
        {
            int[] vetor3 = new int[5];
            for (int i = 0; i < vetor1.Length; i++)
            {
                vetor3[i] = vetor1[i] * vetor2[i];
            }
            return vetor3;
        }

        static int[] Diferença(int[] vetor1, int[] vetor2)
        {
            int[] vetor3 = new int[5];
            for (int i = 0; i < vetor1.Length; i++)
            {
                vetor3[i] = vetor1[i] - vetor2[i];
            }
            return vetor3;
        }
        static void Main(string[] args)
        {
            int[] vetor1 = new int[5];
            int[] vetor2 = new int[5];
            int[] vetor3;



            for (int i = 0; i < vetor1.Length; i++)
            {
                Console.Write($"Informe o número da posição {i + 1} do vetor 1: ");
                vetor1[i] = int.Parse(Console.ReadLine());
            }
            Console.WriteLine();
            for (int i = 0; i < vetor1.Length; i++)
            {
                Console.Write($"Informe o número da posição {i + 1} do vetor 2: ");
                vetor2[i] = int.Parse(Console.ReadLine());
            }

            vetor3 = Soma(vetor1, vetor2);
            Console.WriteLine();
            Console.WriteLine("\nSoma: ");
            for (int i = 0; i < vetor1.Length; i++)
            {
                Console.Write($"{vetor3[i]} ");
            }

            vetor3 = Multiplicação(vetor1, vetor2);
            Console.WriteLine();
            Console.WriteLine("\nMultiplicação: ");
            for (int i = 0; i < vetor1.Length; i++)
            {
                Console.Write($"{vetor3[i]} ");
            }

            vetor3 = Diferença(vetor1, vetor2);
            Console.WriteLine();
            Console.WriteLine("\nDiferença: ");
            for (int i = 0; i < vetor1.Length; i++)
            {
                Console.Write($"{vetor3[i]} ");
            }
        }
    }
}
